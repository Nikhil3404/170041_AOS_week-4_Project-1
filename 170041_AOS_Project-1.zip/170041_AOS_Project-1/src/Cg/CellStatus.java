package Cg;

public enum CellStatus {
	Dead,Alive;
}
